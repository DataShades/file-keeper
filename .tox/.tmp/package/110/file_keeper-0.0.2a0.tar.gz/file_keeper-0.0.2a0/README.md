# file-keeper

Abstraction level for object storages.
